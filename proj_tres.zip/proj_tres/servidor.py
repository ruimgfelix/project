#!/usr/bin/env python
# -*- coding: utf-8 -*-
from flask import Flask, request, make_response, g
import sqlite3
import os
from os.path import isfile

app = Flask(__name__)

DATABASE = str(os.getcwd()) + "/database.db"
print DATABASE

@app.before_request
def before_request():
	db_is_created = isfile(DATABASE)
	g.db = sqlite3.connect("database.db")
	if not db_is_created:
		g.db.execute(u'PRAGMA foreign_keys = ON;')
		g.db.execute(u'CREATE TABLE utilizadores (id INTEGER PRIMARY KEY,nome TEXT,username TEXT,password TEXT);')
		g.db.execute(u'CREATE TABLE albuns (id INTEGER PRIMARY KEY,id_banda INTEGER,nome TEXT,ano_album INTEGER,FOREIGN KEY(id_banda)  			REFERENCES bandas(id));')
		g.db.execute(u'CREATE TABLE bandas (id INTEGER PRIMARY KEY,nome TEXT,ano INTEGER,genero TEXT);')
		g.db.execute(u'CREATE TABLE rates (id INTEGER PRIMARY KEY,designacao TEXT,sigla TEXT);')
		g.db.execute(u'CREATE TABLE listas_albuns (id_user INTEGER,id_album INTEGER,id_rate INTEGER,PRIMARY KEY (id_user, id_album), FOREIGN 			KEY(id_user) REFERENCES utilizadores(id),FOREIGN KEY (id_album) REFERENCES albuns(id)FOREIGN KEY(id_rate) REFERENCES rates(id));')
		g.db.execute(u'INSERT INTO rates (id, designacao, sigla) VALUES(1, “Mau”, “M”),(2, “Mais ou menos”, “MM”),(3, “Suficiente”, “S”),(4, 			“Bom”, “B”),(5, “Muito bom”, “MB”);')
		g.db.commit()

@app.teardown_appcontext
def close_connection(exception):
	if hasattr(g, 'db'):
        	g.db.close()



@app.route('/utilizadores', methods = ["PUT", "POST", "DELETE", "GET"])
def utilizadores():
	if request.method == "PUT":
		print request.data
		r = make_response()
	if request.method == "POST":
		print request.data
		r = make_response()
	if request.method == "DELETE":
		print request.data
		r = make_response()
	if request.method == "GET":
		print request.data
		r = make_response()
 	return r

@app.route('/banda', methods = ["PUT", "POST", "DELETE", "GET"])
def banda():
	if request.method == "PUT":
		print request.data
		r = make_response()
	if request.method == "POST":
		print request.data
		r = make_response()
	if request.method == "DELETE":
		print request.data
		r = make_response()
	if request.method == "GET":
		print request.data
		r = make_response()
	return r

@app.route('/album', methods = ["PUT", "POST", "DELETE", "GET"])
def album():
	if request.method == "PUT":
		print request.data
		r = make_response()
	if request.method == "POST":
		print request.data
		r = make_response()
	if request.method == "DELETE":
		print request.data
		r = make_response()
	if request.method == "GET":
		print request.data
		r = make_response()
	return r

	
if __name__ == '__main__':
	app.run(debug = True)
