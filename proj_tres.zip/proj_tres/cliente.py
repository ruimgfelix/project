#!/usr/bin/env python
# -*- coding: utf-8 -*-
import requests
from sys import *
while True:
	comando = raw_input('Qual é o comando? (exit para sair) -> ')
	com = comando.split(' ')
	
	if com[0] == 'ADD':
		if com[1] == 'USER':
			nome = com[2]
			utilizadores_name = com[3]
			password = com[4]
			dados = {'nome': nome, 'utilizadoresname': utilizadores_name, 'password': password}
			r = requests.put('http://localhost:5000/utilizadores', json = dados) 
		elif com[1] == 'BANDA':
			nome = com[2]
			ano = int(com[3])
			genero = com[4]
			dados = {'nome': nome, 'ano': ano, 'genero': genero}
			r = requests.put('http://localhost:5000/banda', json = dados)
		elif com[1] == 'ALBUM':
			id_banda = int(com[2])
			nome = com[3]
			ano_album = int(com[4])
			dados = {'id_banda': id_banda, 'nome': nome, 'ano_album': ano_album}
			r = requests.post('http://localhost:5000/album', json = dados)
		else:
			id_utilizadores = int(com[1])
			id_album = com[2]
			rate = com[3]	
			dados = {'id_utilizadores': id_utilizadores, 'id_album': id_album, 'rate': rate}
			r = requests.post('http://localhost:5000/rate', json = dados)
			
	elif com[0] == 'REMOVE' or com[0] == 'SHOW':
		if com[1] == 'USER':
			id_utilizadores = int(com[2])
			if com[0] == 'REMOVE':
				dados = {'id_utilizadores': id_utilizadores}
				r = requests.delete('http://localhost:5000/utilizadores', json = dados)
			else:
				dados = {'id_utilizadores': id_utilizadores}
				r = requests.get('http://localhost:5000/utilizadores', json = dados)
		elif com[1] == 'BANDA':
			id_banda = int(com[2])
			if com[0] == 'REMOVE':
				dados = {'id_banda': id_banda}
				r = requests.delete('http://localhost:5000/banda', json = dados)
			else:
				r = requests.get('http://localhost:5000/banda/' + str(id_banda))
		elif com[1] == 'ALBUM':
			id_album = int(com[2])
			if com[0] == 'REMOVE':
				dados = {'id_utilizadores': id_album}
				r = requests.delete('http://localhost:5000/album', json = dados)
			else:
				r = requests.get('http://localhost:5000/album/' + str(id_album))
		elif com[1] == 'ALL':
			if com[2] == 'USERS':
				if com[0] == 'REMOVE':
					r = requests.delete('http://localhost:5000/utilizadores')
				else:
					r = requests.get('http://localhost:5000/utilizadores')
			elif com[2] == 'BANDAS':
				if com[0] == 'REMOVE':
					r = requests.delete('http://localhost:5000/banda')
				else:
					r = requests.get('http://localhost:5000/banda')
			elif com[2] == 'ALBUNS_B':
				if com[0] == 'REMOVE':
					r = requests.delete('http://localhost:5000/utilizadores')
				else:
					r = requests.get('http://localhost:5000/utilizadores')
			elif com[2] == 'ALBUNS_U':
				id_utilizadores = com[3]
				if com[0] == 'REMOVE':
					r = requests.delete('http://localhost:5000/utilizadores')
				else:
					r = requests.get('http://localhost:5000/utilizadores')
			elif com[2] == 'ALBUNS':
				rates = com[3]
	elif com[0] == 'UPDATE':
		if com[1] == 'ALBUM':
			id_utilizadores = int(com[2])
			id_album = com[3]
			rate = com[4]
		elif com[1] == 'USER':
			id_utilizadores = com[2]
			password = com[3]
	elif com[0] == 'exit':
		exit()
	else:
		print 'Comando não reconhecido'
	
			 
